#include <iostream>

int main() {
  std::cout << "Hello, Welcome to Valeo Embedded Linux Academy \n";
  return 0;
}

