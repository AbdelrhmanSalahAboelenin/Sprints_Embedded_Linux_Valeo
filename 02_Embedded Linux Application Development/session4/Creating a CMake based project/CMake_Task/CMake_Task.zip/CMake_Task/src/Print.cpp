#include "Print.h"
#include <iostream>

void Print::printHelloWorld() {
    std::cout << "helloWorld" << std::endl;
}
