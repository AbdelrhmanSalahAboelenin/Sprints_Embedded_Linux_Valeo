#pragma once

class WriteInFile {
public:
	void writeHello();
};
