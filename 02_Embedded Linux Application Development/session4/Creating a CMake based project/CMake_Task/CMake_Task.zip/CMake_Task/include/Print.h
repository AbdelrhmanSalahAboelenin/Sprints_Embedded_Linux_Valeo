#pragma once

class Print {
public:
	void printHelloWorld();
};
