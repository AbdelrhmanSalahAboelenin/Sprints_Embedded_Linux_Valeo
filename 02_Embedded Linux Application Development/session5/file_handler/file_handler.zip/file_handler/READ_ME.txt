1-To build the apps you should make directory such as "Build".

2-Open Build directory..

3-Open the terminal and build the apps.