1-To build the apps you should make directory such as "Build".

2-Open Build directory..

3-run cmake .. , make

4-Open the terminals and build the apps in two terminals 

5-run the request app first then open the fh app.

6-the file_handler is working in the background.

7-the logs does not printed on terminal but it printed on the log_file.
