configuring the Raspberry Pi OS to access your WIFI network and enable SSH connection without the need for a display, keyboard, or mouse. 
